# DFCI Font Editor v1

GUI sửa thủ công font Dengeki Bunko: Fighting Climax Ignition.

## Chức năng

- Hiện toàn bộ glyph trong `Font00.fnt`
- Preview từng glyph từ atlas GXT
- Nếu thư mục font có `vi_mapping.json`, các glyph tunnel sẽ hiện **ký tự tiếng Việt thật**
- Search theo ký tự / code / index
- `Export glyph`: xuất riêng PNG + JSON metric
- `Import PNG vào glyph này`: ghi PNG vào đúng rectangle cũ
- `Export Font`: xuất toàn bộ glyph thành PNG + `font_manifest.json`
- `Import Font`: nhập toàn bộ PNG đã sửa rồi build lại GXT/FNT

## Quan trọng

Tool **không repack atlas**, không đổi UV và không đổi metric.
Nếu PNG import khác kích thước, nó sẽ resize về đúng W×H hiện tại.

## Cấu trúc Export Font

    export/
      font_manifest.json
      glyphs/
        0000_0x....png
        0001_0x....png
        ...

Có thể sửa PNG hàng loạt trong Photoshop/Aseprite/GIMP rồi dùng Import Font.

## Yêu cầu
Python 3.10+
Pillow

Chạy:
    run_font_editor.bat
