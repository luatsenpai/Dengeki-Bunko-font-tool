#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import gzip, json, struct, sys, shutil, traceback
from dataclasses import dataclass
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk

FNT_HEADER_SIZE = 0x3E
GLYPH_RECORD_SIZE = 0x16
PAGE_W = 512
PAGE_H = 512
PAGE_COUNT = 14
GXT_HEADER_SIZE = 0x40

@dataclass
class Glyph:
    code:int
    page:int
    center_x:int
    neg_half_width:int
    neg_top:int
    advance:int
    width:int
    height:int
    atlas_x:int
    atlas_y:int

    @classmethod
    def unpack(cls, raw, off):
        return cls(*struct.unpack_from("<I H h h h H H H H H", raw, off))
    def pack(self):
        return struct.pack("<I H h h h H H H H H",
                           self.code,self.page,self.center_x,self.neg_half_width,
                           self.neg_top,self.advance,self.width,self.height,
                           self.atlas_x,self.atlas_y)

_MORTON=None
def part1by1(n):
    n &= 0xFFFF
    n=(n|(n<<8)) & 0x00FF00FF
    n=(n|(n<<4)) & 0x0F0F0F0F
    n=(n|(n<<2)) & 0x33333333
    n=(n|(n<<1)) & 0x55555555
    return n

def morton_table():
    global _MORTON
    if _MORTON is None:
        tab=[0]*(PAGE_W*PAGE_H)
        k=0
        for y in range(PAGE_H):
            yy=part1by1(y)
            for x in range(PAGE_W):
                tab[k]=yy | (part1by1(x)<<1)
                k+=1
        _MORTON=tab
    return _MORTON

def load_fnt(path):
    raw=path.read_bytes()
    if len(raw)<FNT_HEADER_SIZE:
        raise ValueError("FNT quá nhỏ.")
    count=struct.unpack_from("<I",raw,0x34)[0]
    exp=FNT_HEADER_SIZE + count*GLYPH_RECORD_SIZE
    if len(raw)<exp:
        raise ValueError("FNT bị cắt.")
    hdr=bytearray(raw[:FNT_HEADER_SIZE])
    glyphs=[Glyph.unpack(raw,FNT_HEADER_SIZE+i*GLYPH_RECORD_SIZE) for i in range(count)]
    tail=raw[exp:]
    return hdr,glyphs,tail

def save_fnt(path,hdr,glyphs,tail):
    h=bytearray(hdr)
    struct.pack_into("<I",h,0x34,len(glyphs))
    path.write_bytes(bytes(h)+b"".join(g.pack() for g in glyphs)+tail)

def decode_code(code):
    if code==0:
        return None
    try:
        if code<=0xFF:
            return bytes([code]).decode("cp932")
        if code<=0xFFFF:
            return bytes([(code>>8)&255,code&255]).decode("cp932")
    except Exception:
        return None
    return None

def read_gxt(path):
    with gzip.open(path,"rb") as f:
        raw=f.read()
    if raw[:4]!=b"GXT\x00":
        raise ValueError(f"{path.name} không phải GXT.")
    width,height=struct.unpack_from("<HH",raw,0x38)
    size=struct.unpack_from("<I",raw,0x0C)[0]
    if (width,height)!=(512,512) or size!=512*512*4:
        raise ValueError(f"{path.name}: chỉ hỗ trợ 512x512 RGBA8888.")
    payload=raw[GXT_HEADER_SIZE:GXT_HEADER_SIZE+size]
    lin=bytearray(size)
    tab=morton_table()
    for lp,mp in enumerate(tab):
        lin[lp*4:lp*4+4]=payload[mp*4:mp*4+4]
    return bytearray(raw[:GXT_HEADER_SIZE]),lin

def write_gxt(path,hdr,lin):
    payload=bytearray(len(lin))
    tab=morton_table()
    for lp,mp in enumerate(tab):
        payload[mp*4:mp*4+4]=lin[lp*4:lp*4+4]
    with open(path,"wb") as fh:
        with gzip.GzipFile(filename="",mode="wb",fileobj=fh,mtime=0) as gz:
            gz.write(bytes(hdr)+bytes(payload))

def glyph_alpha_from_page(lin,g):
    img=Image.new("L",(g.width,g.height),0)
    pix=img.load()
    for y in range(g.height):
        for x in range(g.width):
            off=((g.atlas_y+y)*PAGE_W+(g.atlas_x+x))*4
            pix[x,y]=lin[off+3]
    return img

def paint_alpha(lin,g,img):
    if img.mode!="L":
        img=img.convert("L")
    if img.size!=(g.width,g.height):
        img=img.resize((g.width,g.height),Image.Resampling.LANCZOS)
    pix=img.load()
    for y in range(g.height):
        for x in range(g.width):
            off=((g.atlas_y+y)*PAGE_W+(g.atlas_x+x))*4
            lin[off:off+4]=bytes((255,255,255,pix[x,y]))

def load_vi_mapping(folder):
    p=folder/"vi_mapping.json"
    if not p.is_file():
        return {}
    try:
        data=json.loads(p.read_text(encoding="utf-8-sig"))
        mp=data.get("mapping",{})
        code_to_vi={}
        for vi,ent in mp.items():
            if not isinstance(ent,dict):
                continue
            fc=ent.get("fnt_code")
            if not fc:
                continue
            try:
                code=int(fc,16)
                code_to_vi[code]=vi
            except Exception:
                pass
        return code_to_vi
    except Exception:
        return {}

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("DFCI Font Editor")
        self.geometry("1120x760")
        self.minsize(980,680)

        self.folder_var=tk.StringVar()
        self.search_var=tk.StringVar()
        self.status_var=tk.StringVar(value="Chọn thư mục font.")
        self.show_vi_var=tk.BooleanVar(value=True)

        self.hdr=None
        self.glyphs=[]
        self.tail=b""
        self.pages={}
        self.code_to_vi={}
        self.selected_index=None
        self.preview_tk=None

        self.build_ui()

    def build_ui(self):
        top=ttk.Frame(self,padding=10)
        top.pack(fill="x")
        ttk.Label(top,text="Thư mục font:").pack(side="left")
        ttk.Entry(top,textvariable=self.folder_var).pack(side="left",fill="x",expand=True,padx=6)
        ttk.Button(top,text="Mở…",command=self.choose_folder).pack(side="left")
        ttk.Button(top,text="Load",command=self.load_font).pack(side="left",padx=(6,0))

        act=ttk.Frame(self,padding=(10,0,10,8))
        act.pack(fill="x")
        ttk.Button(act,text="Export Font",command=self.export_font).pack(side="left")
        ttk.Button(act,text="Import Font",command=self.import_font).pack(side="left",padx=6)
        ttk.Button(act,text="Export glyph",command=self.export_selected).pack(side="left")
        ttk.Checkbutton(act,text="Hiện tiếng Việt nếu glyph đã thay",variable=self.show_vi_var,command=self.refresh_tree).pack(side="left",padx=12)
        ttk.Label(act,text="Tìm:").pack(side="left",padx=(20,4))
        ent=ttk.Entry(act,textvariable=self.search_var,width=26)
        ent.pack(side="left")
        ent.bind("<KeyRelease>",lambda e:self.refresh_tree())

        main=ttk.Panedwindow(self,orient="horizontal")
        main.pack(fill="both",expand=True,padx=10,pady=(0,10))

        left=ttk.Frame(main)
        right=ttk.Frame(main)
        main.add(left,weight=3)
        main.add(right,weight=2)

        cols=("idx","display","code","page","xy","size","adv")
        self.tree=ttk.Treeview(left,columns=cols,show="headings",selectmode="browse")
        headings={"idx":"#","display":"Ký tự","code":"Code","page":"Page","xy":"X,Y","size":"W×H","adv":"Advance"}
        widths={"idx":60,"display":110,"code":90,"page":60,"xy":100,"size":80,"adv":70}
        for c in cols:
            self.tree.heading(c,text=headings[c])
            self.tree.column(c,width=widths[c],anchor="center")
        ys=ttk.Scrollbar(left,orient="vertical",command=self.tree.yview)
        self.tree.configure(yscrollcommand=ys.set)
        self.tree.pack(side="left",fill="both",expand=True)
        ys.pack(side="right",fill="y")
        self.tree.bind("<<TreeviewSelect>>",self.on_select)

        info=ttk.LabelFrame(right,text="Glyph",padding=10)
        info.pack(fill="x")
        self.info_text=tk.StringVar(value="Chưa chọn glyph.")
        ttk.Label(info,textvariable=self.info_text,justify="left").pack(anchor="w")

        prev=ttk.LabelFrame(right,text="Preview",padding=10)
        prev.pack(fill="both",expand=True,pady=(10,0))
        self.preview=ttk.Label(prev,anchor="center")
        self.preview.pack(fill="both",expand=True)

        buttons=ttk.Frame(prev)
        buttons.pack(fill="x",pady=(10,0))
        ttk.Button(buttons,text="Export glyph này",command=self.export_selected).pack(side="left")
        ttk.Button(buttons,text="Import PNG vào glyph này",command=self.import_selected).pack(side="left",padx=6)

        ttk.Label(self,textvariable=self.status_var,anchor="w").pack(fill="x",padx=10,pady=(0,8))

    def choose_folder(self):
        p=filedialog.askdirectory(title="Chọn thư mục có Font00.fnt và Font_0000..0013.gxt.gz")
        if p:
            self.folder_var.set(p)

    def load_font(self):
        try:
            folder=Path(self.folder_var.get())
            if not folder.is_dir():
                raise ValueError("Thư mục không hợp lệ.")
            self.hdr,self.glyphs,self.tail=load_fnt(folder/"Font00.fnt")
            self.pages={}
            for p in range(PAGE_COUNT):
                fn=folder/f"Font_{p:04d}.gxt.gz"
                if not fn.is_file():
                    raise ValueError(f"Thiếu {fn.name}")
                self.pages[p]=list(read_gxt(fn))
            self.code_to_vi=load_vi_mapping(folder)
            self.selected_index=None
            self.refresh_tree()
            self.status_var.set(f"Đã load {len(self.glyphs)} glyph. Mapping Việt: {len(self.code_to_vi)}.")
        except Exception as e:
            messagebox.showerror("Load font",str(e))

    def display_char(self,g):
        if self.show_vi_var.get() and g.code in self.code_to_vi:
            return self.code_to_vi[g.code]
        c=decode_code(g.code)
        if c is None:
            return "?"
        if c.isspace():
            return {" ":"[SPACE]","\t":"[TAB]","\r":"[CR]","\n":"[LF]"}.get(c,repr(c))
        return c

    def refresh_tree(self):
        if not self.glyphs:
            return
        q=self.search_var.get().strip().lower()
        for i in self.tree.get_children():
            self.tree.delete(i)
        for idx,g in enumerate(self.glyphs):
            disp=self.display_char(g)
            code=f"0x{g.code:04X}" if g.code<=0xFFFF else f"0x{g.code:X}"
            hay=f"{idx} {disp} {code} {g.page} {g.atlas_x},{g.atlas_y} {g.width}x{g.height}".lower()
            if q and q not in hay:
                continue
            self.tree.insert("", "end", iid=str(idx), values=(idx,disp,code,g.page,f"{g.atlas_x},{g.atlas_y}",f"{g.width}×{g.height}",g.advance))

    def on_select(self,event=None):
        sel=self.tree.selection()
        if not sel:
            return
        idx=int(sel[0])
        self.selected_index=idx
        g=self.glyphs[idx]
        disp=self.display_char(g)
        vi=self.code_to_vi.get(g.code)
        cp=decode_code(g.code)
        self.info_text.set(
            f"Index: {idx}\nHiển thị: {disp}\nFNT code: 0x{g.code:04X}\n"
            f"CP932 gốc: {repr(cp)}\nViệt mapping: {repr(vi) if vi else '-'}\n"
            f"Page: {g.page}\nAtlas: X={g.atlas_x}, Y={g.atlas_y}\n"
            f"Size: {g.width}×{g.height}\nAdvance: {g.advance}\n"
            f"centerX: {g.center_x}\nnegHalfWidth: {g.neg_half_width}\nnegTop: {g.neg_top}"
        )
        if 0<=g.page<PAGE_COUNT and g.width>0 and g.height>0:
            img=glyph_alpha_from_page(self.pages[g.page][1],g)
            scale=max(1,min(10,220//max(1,max(img.size))))
            prev=img.resize((img.width*scale,img.height*scale),Image.Resampling.NEAREST).convert("RGBA")
            self.preview_tk=ImageTk.PhotoImage(prev)
            self.preview.configure(image=self.preview_tk)
        else:
            self.preview.configure(image="")
            self.preview_tk=None

    def export_selected(self):
        try:
            if self.selected_index is None:
                raise ValueError("Chưa chọn glyph.")
            g=self.glyphs[self.selected_index]
            folder=filedialog.askdirectory(title="Chọn thư mục xuất glyph")
            if not folder:
                return
            out=Path(folder)
            img=glyph_alpha_from_page(self.pages[g.page][1],g)
            safe=f"{self.selected_index:04d}_0x{g.code:04X}"
            img.save(out/f"{safe}.png")
            meta={"index":self.selected_index,"display":self.display_char(g),"code":f"0x{g.code:04X}",
                  "page":g.page,"x":g.atlas_x,"y":g.atlas_y,"width":g.width,"height":g.height,
                  "advance":g.advance,"center_x":g.center_x,"neg_half_width":g.neg_half_width,"neg_top":g.neg_top}
            (out/f"{safe}.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding="utf-8")
            self.status_var.set(f"Đã export glyph {safe}.")
        except Exception as e:
            messagebox.showerror("Export glyph",str(e))

    def import_selected(self):
        try:
            if self.selected_index is None:
                raise ValueError("Chưa chọn glyph.")
            p=filedialog.askopenfilename(title="Chọn PNG",filetypes=[("PNG","*.png"),("All files","*.*")])
            if not p:
                return
            g=self.glyphs[self.selected_index]
            img=Image.open(p).convert("L")
            paint_alpha(self.pages[g.page][1],g,img)
            self.on_select()
            self.status_var.set(f"Đã import PNG vào glyph #{self.selected_index}. Chưa ghi file.")
        except Exception as e:
            messagebox.showerror("Import glyph",str(e))

    def export_font(self):
        try:
            if not self.glyphs:
                raise ValueError("Chưa load font.")
            folder=filedialog.askdirectory(title="Chọn thư mục Export Font")
            if not folder:
                return
            out=Path(folder)
            glyph_dir=out/"glyphs"
            glyph_dir.mkdir(parents=True,exist_ok=True)
            manifest=[]
            for idx,g in enumerate(self.glyphs):
                disp=self.code_to_vi.get(g.code) or decode_code(g.code)
                fn=None
                if 0<=g.page<PAGE_COUNT and g.width>0 and g.height>0:
                    fn=f"{idx:04d}_0x{g.code:04X}.png"
                    glyph_alpha_from_page(self.pages[g.page][1],g).save(glyph_dir/fn)
                manifest.append({"index":idx,"display":disp,"code":f"0x{g.code:04X}","page":g.page,
                                 "x":g.atlas_x,"y":g.atlas_y,"width":g.width,"height":g.height,
                                 "advance":g.advance,"center_x":g.center_x,"neg_half_width":g.neg_half_width,
                                 "neg_top":g.neg_top,"png":fn,"vi_replacement":self.code_to_vi.get(g.code)})
            (out/"font_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
            messagebox.showinfo("Export Font",f"Đã xuất {len(manifest)} glyph vào:\n{out}")
        except Exception as e:
            messagebox.showerror("Export Font",str(e))

    def import_font(self):
        try:
            if not self.glyphs:
                raise ValueError("Chưa load font.")
            folder=filedialog.askdirectory(title="Chọn thư mục Export Font đã chỉnh")
            if not folder:
                return
            base=Path(folder)
            manifest_path=base/"font_manifest.json"
            glyph_dir=base/"glyphs"
            if not manifest_path.is_file():
                raise ValueError("Thiếu font_manifest.json")
            data=json.loads(manifest_path.read_text(encoding="utf-8"))
            changed=0
            for ent in data:
                idx=ent.get("index")
                fn=ent.get("png")
                if not isinstance(idx,int) or not (0<=idx<len(self.glyphs)) or not fn:
                    continue
                p=glyph_dir/fn
                if not p.is_file():
                    continue
                g=self.glyphs[idx]
                paint_alpha(self.pages[g.page][1],g,Image.open(p).convert("L"))
                changed+=1

            out=filedialog.askdirectory(title="Chọn thư mục ghi font đã import")
            if not out:
                return
            outp=Path(out)
            outp.mkdir(parents=True,exist_ok=True)
            src=Path(self.folder_var.get())
            for item in src.iterdir():
                if item.is_file():
                    shutil.copy2(item,outp/item.name)
            for p in range(PAGE_COUNT):
                write_gxt(outp/f"Font_{p:04d}.gxt.gz",self.pages[p][0],self.pages[p][1])
            save_fnt(outp/"Font00.fnt",self.hdr,self.glyphs,self.tail)
            messagebox.showinfo("Import Font",f"Đã import {changed} glyph và ghi font vào:\n{outp}")
        except Exception as e:
            messagebox.showerror("Import Font",str(e))

if __name__=="__main__":
    App().mainloop()
