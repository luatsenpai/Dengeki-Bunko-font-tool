#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import codecs
import json
import os
import shutil
import sys
import traceback
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP_TITLE = "DFCI Replace Tool"

TEXT_EXTS = {
    ".txt", ".csv", ".tsv", ".ini", ".cfg", ".conf", ".json", ".xml",
    ".yml", ".yaml", ".lua", ".ks", ".scr", ".script", ".msg", ".mes",
    ".dat", ".lst", ".tbl", ".po", ".srt", ".ass", ".sub"
}

def load_mapping(path: Path):
    data = json.loads(path.read_text(encoding="utf-8-sig"))
    mp = data.get("mapping", data)
    if not isinstance(mp, dict):
        raise ValueError("vi_mapping.json không hợp lệ.")

    replacements = {}
    for src, ent in mp.items():
        if not isinstance(src, str) or len(src) != 1 or not isinstance(ent, dict):
            continue
        hx = ent.get("cp932_bytes_hex")
        if not hx:
            continue
        try:
            b = bytes(int(x, 16) for x in hx.split())
            dst = b.decode("cp932")
        except Exception as e:
            raise ValueError(f"Map lỗi tại ký tự {src!r}: {hx!r}") from e
        replacements[src] = dst

    if not replacements:
        raise ValueError(
            "Không có mapping CP932 tunnel trong file JSON.\n"
            "Hãy tạo font bằng chế độ CP932 tunnel."
        )
    return replacements

def looks_binary(raw: bytes):
    if raw.startswith((
        codecs.BOM_UTF8,
        codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE,
        codecs.BOM_UTF32_LE, codecs.BOM_UTF32_BE
    )):
        return False
    if b"\x00" in raw[:4096]:
        return True
    sample = raw[:8192]
    if not sample:
        return False
    bad = sum(1 for b in sample if b < 32 and b not in (9,10,13,12))
    return bad / len(sample) > 0.03

def decode_text(raw: bytes, ext: str):
    if raw.startswith(codecs.BOM_UTF8):
        return raw[3:].decode("utf-8"), "utf-8-sig"
    if raw.startswith(codecs.BOM_UTF16_LE):
        return raw[2:].decode("utf-16-le"), "utf-16-le"
    if raw.startswith(codecs.BOM_UTF16_BE):
        return raw[2:].decode("utf-16-be"), "utf-16-be"
    if raw.startswith(codecs.BOM_UTF32_LE):
        return raw[4:].decode("utf-32-le"), "utf-32-le"
    if raw.startswith(codecs.BOM_UTF32_BE):
        return raw[4:].decode("utf-32-be"), "utf-32-be"

    if looks_binary(raw):
        return None

    try:
        return raw.decode("utf-8"), "utf-8"
    except UnicodeDecodeError:
        pass

    try:
        txt = raw.decode("cp932")
        if ext.lower() not in TEXT_EXTS:
            probe = txt[:8192]
            if probe:
                bad = sum(1 for c in probe if ord(c) < 32 and c not in "\t\r\n\f")
                if bad / len(probe) > 0.01:
                    return None
        return txt, "cp932"
    except UnicodeDecodeError:
        return None

def encode_preserve(text: str, enc: str):
    if enc == "utf-8-sig":
        return codecs.BOM_UTF8 + text.encode("utf-8")
    if enc == "utf-16-le":
        return codecs.BOM_UTF16_LE + text.encode("utf-16-le")
    if enc == "utf-16-be":
        return codecs.BOM_UTF16_BE + text.encode("utf-16-be")
    if enc == "utf-32-le":
        return codecs.BOM_UTF32_LE + text.encode("utf-32-le")
    if enc == "utf-32-be":
        return codecs.BOM_UTF32_BE + text.encode("utf-32-be")
    return text.encode(enc)

def replace_once(text: str, mp: dict[str,str]):
    out = []
    n = 0
    for c in text:
        r = mp.get(c)
        if r is None:
            out.append(c)
        else:
            out.append(r)
            n += 1
    return "".join(out), n

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("670x430")
        self.minsize(610, 390)

        self.folder = tk.StringVar()
        self.mapping = tk.StringVar()
        self.force_cp932 = tk.BooleanVar(value=True)
        self.status = tk.StringVar(value="Chọn bảng map và thư mục text.")

        self.build_ui()
        self.autofind_mapping()

    def build_ui(self):
        box = ttk.Frame(self, padding=20)
        box.pack(fill="both", expand=True)

        ttk.Label(
            box,
            text="Công cụ thay ký tự tự động DFCI",
            font=("Segoe UI", 15, "bold")
        ).pack(pady=(0,18))

        f = ttk.Frame(box)
        f.pack(fill="x")

        ttk.Label(f, text="Bảng map:", width=14).grid(row=0,column=0,sticky="w",pady=5)
        ttk.Entry(f,textvariable=self.mapping).grid(row=0,column=1,sticky="ew",padx=6)
        ttk.Button(f,text="Chọn…",command=self.pick_map).grid(row=0,column=2)

        ttk.Label(f,text="Thư mục text:",width=14).grid(row=1,column=0,sticky="w",pady=5)
        ttk.Entry(f,textvariable=self.folder).grid(row=1,column=1,sticky="ew",padx=6)
        ttk.Button(f,text="Chọn…",command=self.pick_folder).grid(row=1,column=2)
        f.columnconfigure(1,weight=1)

        ttk.Checkbutton(
            box,
            variable=self.force_cp932,
            text="Xuất file có thay đổi sang CP932 (khuyến nghị cho game gốc)"
        ).pack(anchor="w", pady=(12,0))

        ttk.Button(
            box,
            text="MỞ THƯ MỤC TEXT VÀ TẠO BẢN _VI",
            command=self.run
        ).pack(fill="x", ipady=14, pady=(18,10))

        ttk.Label(box,textvariable=self.status,wraplength=610).pack(anchor="w")

        self.log = tk.Text(box,height=10,state="disabled",wrap="word")
        self.log.pack(fill="both",expand=True,pady=(10,0))

    def autofind_mapping(self):
        here = Path(sys.argv[0]).resolve().parent
        p = here / "vi_mapping.json"
        if p.is_file():
            self.mapping.set(str(p))

    def pick_map(self):
        p = filedialog.askopenfilename(
            title="Chọn vi_mapping.json",
            filetypes=[("DFCI mapping","vi_mapping.json"),("JSON","*.json"),("All files","*.*")]
        )
        if p:
            self.mapping.set(p)

    def pick_folder(self):
        p = filedialog.askdirectory(title="Chọn thư mục text")
        if p:
            self.folder.set(p)
            if not self.mapping.get():
                src = Path(p)
                for q in (src/"vi_mapping.json", src.parent/"vi_mapping.json"):
                    if q.is_file():
                        self.mapping.set(str(q))
                        break

    def say(self,s=""):
        self.log.configure(state="normal")
        self.log.insert("end",s+"\n")
        self.log.see("end")
        self.log.configure(state="disabled")
        self.update_idletasks()

    def run(self):
        try:
            src = Path(self.folder.get()).resolve()
            mpath = Path(self.mapping.get()).resolve()
            if not src.is_dir():
                raise ValueError("Chưa chọn thư mục text hợp lệ.")
            if not mpath.is_file():
                raise ValueError("Chưa chọn vi_mapping.json hợp lệ.")

            dst = src.parent / (src.name + "_vi")
            if dst.exists():
                if not messagebox.askyesno(
                    "Thư mục đã tồn tại",
                    f"{dst.name} đã tồn tại.\n\nXóa và tạo lại?"
                ):
                    return
                shutil.rmtree(dst)

            mp = load_mapping(mpath)

            self.log.configure(state="normal")
            self.log.delete("1.0","end")
            self.log.configure(state="disabled")

            self.say(f"Nguồn : {src}")
            self.say(f"Đích  : {dst}")
            self.say(f"Map   : {mpath}")
            self.say(f"Ký tự map: {len(mp)}")
            self.say("")

            dst.mkdir(parents=True)

            files_total = 0
            files_changed = 0
            replacements = 0
            binaries = 0

            for cur, dirs, files in os.walk(src):
                curp = Path(cur)
                rel = curp.relative_to(src)
                outdir = dst / rel
                outdir.mkdir(parents=True,exist_ok=True)

                for name in files:
                    files_total += 1
                    inp = curp / name
                    out = outdir / name
                    raw = inp.read_bytes()
                    dec = decode_text(raw, inp.suffix)

                    if dec is None:
                        shutil.copy2(inp,out)
                        binaries += 1
                        self.say(f"COPY      {inp.relative_to(src)}")
                        continue

                    text, enc = dec
                    new, n = replace_once(text,mp)

                    if n == 0:
                        shutil.copy2(inp,out)
                        self.say(f"UNCHANGED {inp.relative_to(src)}")
                        continue

                    if self.force_cp932.get():
                        try:
                            outbytes = new.encode("cp932")
                        except UnicodeEncodeError as e:
                            bad = new[e.start:e.end]
                            raise RuntimeError(
                                f"{inp.relative_to(src)} còn ký tự không encode được CP932: {bad!r}\n"
                                "Có thể file chứa ký tự Unicode ngoài bảng map."
                            )
                    else:
                        outbytes = encode_preserve(new,enc)

                    out.write_bytes(outbytes)
                    try:
                        shutil.copystat(inp,out)
                    except Exception:
                        pass

                    files_changed += 1
                    replacements += n
                    self.say(
                        f"REPLACE   {inp.relative_to(src)}  "
                        f"[{enc} -> {'cp932' if self.force_cp932.get() else enc}]  {n}"
                    )

            self.status.set(
                f"Hoàn tất — {replacements} ký tự / {files_changed} file. "
                f"Output: {dst.name}"
            )
            self.say("")
            self.say(f"Hoàn tất: {replacements} ký tự trong {files_changed}/{files_total} file.")
            self.say(f"File binary/không xác định: {binaries} (copy nguyên).")
            self.say(f"Output: {dst}")

            messagebox.showinfo(
                "Hoàn tất",
                f"Đã tạo:\n{dst}\n\n"
                f"File: {files_total}\n"
                f"File thay đổi: {files_changed}\n"
                f"Ký tự đã thay: {replacements}"
            )

        except Exception as e:
            self.status.set("Có lỗi.")
            self.say("")
            self.say("ERROR:")
            self.say(traceback.format_exc())
            messagebox.showerror(APP_TITLE,str(e))

if __name__ == "__main__":
    App().mainloop()
