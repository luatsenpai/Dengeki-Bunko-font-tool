# DFCI Replace Tool v1.1

## Chức năng

- Chọn `vi_mapping.json` do DFCI Font Tool tạo.
- Chọn thư mục chứa text đã dịch.
- Tool tạo thư mục mới nằm ngang cấp:

    text
    text_vi

- Giữ nguyên toàn bộ tên file.
- Giữ nguyên toàn bộ tên subfolder.
- Giữ nguyên cấu trúc cây thư mục.
- Quét đệ quy mọi file.
- Chỉ thay các ký tự có trong bảng map.
- File binary/không nhận diện được là text sẽ copy nguyên trạng.
- Không thêm file report vào cây output.

## Vì sao mặc định xuất CP932?

Font game dùng mã CP932 tunnel.

Ví dụ mapping:

    ă -> F0 40

Nếu chỉ thay `ă` bằng ký tự PUA nhưng lưu lại dưới UTF-8 thì byte thực tế KHÔNG phải `F0 40`.

Vì vậy chế độ mặc định:

    UTF-8 bản dịch
        -> thay ký tự Việt bằng PUA đã map
        -> encode toàn bộ file thành CP932
        -> game nhận đúng byte F0 40 / F0 41 / ...

Nếu format text cụ thể của game cần giữ encoding gốc, bỏ tick:
`Xuất file có thay đổi sang CP932`.

## Chạy

Double click:

    run_replace_tool.bat

hoặc:

    py dfci_replace_tool.py

Không cần Pillow.
