@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py dfci_replace_tool.py
) else (
    python dfci_replace_tool.py
)
if errorlevel 1 pause
