@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
    py -m pip install -r requirements.txt
    py dfci_font_tool.py
) else (
    python -m pip install -r requirements.txt
    python dfci_font_tool.py
)
if errorlevel 1 pause
