#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DFCI Font Tool
Dengeki Bunko: Fighting Climax Ignition - Font00.fnt + Font_0000..0013.gxt.gz

Purpose:
- Load the game's existing FNT + GXT atlas pages.
- Load a TTF/OTF font.
- Add ONLY characters missing from the existing font.
- Reuse free space in EXISTING atlas pages. No new atlas page is created.
- Preserve every existing glyph record and every existing atlas rectangle.
- Default encoding mode: CP932 tunneling using unused CP932 PUA byte codes.
- Optional Unicode-direct mode for experiments with a patched text renderer.

Requires: Python 3.10+ and Pillow
"""

from __future__ import annotations
import gzip
import json
import os
import shutil
import struct
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError:
    raise SystemExit("Pillow is required. Install with: py -m pip install Pillow")

FNT_HEADER_SIZE = 0x3E
GLYPH_RECORD_SIZE = 0x16
GXT_HEADER_SIZE = 0x40
PAGE_W = 512
PAGE_H = 512
NORMAL_PAGE_COUNT = 14  # 0000..0013. 0014 is BC3 and is intentionally untouched.

# Full set of precomposed Vietnamese Latin letters normally needed by translations.
VIETNAMESE_CHARSET = (
    "ÀÁẢÃẠĂẰẮẲẴẶÂẦẤẨẪẬ"
    "ÈÉẺẼẸÊỀẾỂỄỆ"
    "ÌÍỈĨỊ"
    "ÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢ"
    "ÙÚỦŨỤƯỪỨỬỮỰ"
    "ỲÝỶỸỴ"
    "Đ"
    "àáảãạăằắẳẵặâầấẩẫậ"
    "èéẻẽẹêềếểễệ"
    "ìíỉĩị"
    "òóỏõọôồốổỗộơờớởỡợ"
    "ùúủũụưừứửữự"
    "ỳýỷỹỵ"
    "đ"
)

@dataclass
class Glyph:
    code: int
    page: int
    center_x: int
    neg_half_width: int
    neg_top: int
    advance: int
    width: int
    height: int
    atlas_x: int
    atlas_y: int

    @classmethod
    def unpack(cls, raw: bytes, off: int) -> "Glyph":
        vals = struct.unpack_from("<I H h h h H H H H H", raw, off)
        return cls(*vals)

    def pack(self) -> bytes:
        return struct.pack(
            "<I H h h h H H H H H",
            self.code, self.page, self.center_x, self.neg_half_width,
            self.neg_top, self.advance, self.width, self.height,
            self.atlas_x, self.atlas_y
        )

def decode_existing_code(code: int) -> str | None:
    if code == 0:
        return None
    try:
        if code <= 0xFF:
            return bytes([code]).decode("cp932")
        if code <= 0xFFFF:
            return bytes([(code >> 8) & 0xFF, code & 0xFF]).decode("cp932")
    except Exception:
        return None
    return None

def load_fnt(path: Path):
    raw = path.read_bytes()
    if len(raw) < FNT_HEADER_SIZE:
        raise ValueError("Font00.fnt is too small.")
    glyph_count = struct.unpack_from("<I", raw, 0x34)[0]
    expected = FNT_HEADER_SIZE + glyph_count * GLYPH_RECORD_SIZE
    if len(raw) < expected:
        raise ValueError(
            f"FNT truncated: header says {glyph_count} glyphs "
            f"({expected} bytes required), file has {len(raw)}."
        )
    header = bytearray(raw[:FNT_HEADER_SIZE])
    glyphs = [
        Glyph.unpack(raw, FNT_HEADER_SIZE + i * GLYPH_RECORD_SIZE)
        for i in range(glyph_count)
    ]
    tail = raw[expected:]
    return header, glyphs, tail

def save_fnt(path: Path, header: bytearray, glyphs: list[Glyph], tail: bytes):
    hdr = bytearray(header)
    struct.pack_into("<I", hdr, 0x34, len(glyphs))
    out = bytes(hdr) + b"".join(g.pack() for g in glyphs) + tail
    path.write_bytes(out)

def part1by1(n: int) -> int:
    n &= 0x0000FFFF
    n = (n | (n << 8)) & 0x00FF00FF
    n = (n | (n << 4)) & 0x0F0F0F0F
    n = (n | (n << 2)) & 0x33333333
    n = (n | (n << 1)) & 0x55555555
    return n

# Cache Morton indices for 512x512 once.
_MORTON = None
def morton_table():
    global _MORTON
    if _MORTON is None:
        tab = [0] * (PAGE_W * PAGE_H)
        k = 0
        for y in range(PAGE_H):
            yy = part1by1(y)
            for x in range(PAGE_W):
                tab[k] = yy | (part1by1(x) << 1)
                k += 1
        _MORTON = tab
    return _MORTON

def read_gxt_rgba(path: Path) -> tuple[bytearray, bytearray]:
    """Return (header_0x40, linear RGBA bytearray) for 512x512 U8U8U8U8 swizzled GXT."""
    with gzip.open(path, "rb") as f:
        raw = f.read()
    if len(raw) < GXT_HEADER_SIZE:
        raise ValueError(f"{path.name}: invalid GXT.")
    if raw[:4] != b"GXT\x00":
        raise ValueError(f"{path.name}: not a GXT.")
    width, height = struct.unpack_from("<HH", raw, 0x38)
    tex_type = struct.unpack_from("<I", raw, 0x30)[0]
    tex_format = struct.unpack_from("<I", raw, 0x34)[0]
    data_offset = struct.unpack_from("<I", raw, 0x0C)[0]
    data_size = struct.unpack_from("<I", raw, 0x10)[0]
    if (width, height) != (512, 512):
        raise ValueError(f"{path.name}: expected 512x512, got {width}x{height}.")
    if data_size != 512 * 512 * 4:
        raise ValueError(f"{path.name}: expected RGBA8888 data, got dataSize=0x{data_size:X}.")
    payload = raw[data_offset:data_offset + data_size]
    if len(payload) != data_size:
        raise ValueError(f"{path.name}: truncated texture payload.")

    linear = bytearray(data_size)
    tab = morton_table()
    for linear_pixel, morton_pixel in enumerate(tab):
        src = morton_pixel * 4
        dst = linear_pixel * 4
        linear[dst:dst+4] = payload[src:src+4]
    return bytearray(raw[:GXT_HEADER_SIZE]), linear

def write_gxt_rgba(path: Path, header: bytearray, linear: bytearray):
    if len(linear) != PAGE_W * PAGE_H * 4:
        raise ValueError("Internal error: bad linear texture size.")
    payload = bytearray(len(linear))
    tab = morton_table()
    for linear_pixel, morton_pixel in enumerate(tab):
        src = linear_pixel * 4
        dst = morton_pixel * 4
        payload[dst:dst+4] = linear[src:src+4]
    raw = bytes(header) + bytes(payload)
    with open(path, "wb") as fout:
        with gzip.GzipFile(filename="", mode="wb", fileobj=fout, mtime=0) as gz:
            gz.write(raw)

def build_occupancy(glyphs: list[Glyph], padding: int):
    occ = [bytearray(PAGE_W * PAGE_H) for _ in range(NORMAL_PAGE_COUNT)]
    for g in glyphs:
        if not (0 <= g.page < NORMAL_PAGE_COUNT):
            continue
        if g.width <= 0 or g.height <= 0:
            continue
        x0 = max(0, g.atlas_x - padding)
        y0 = max(0, g.atlas_y - padding)
        x1 = min(PAGE_W, g.atlas_x + g.width + padding)
        y1 = min(PAGE_H, g.atlas_y + g.height + padding)
        o = occ[g.page]
        for y in range(y0, y1):
            start = y * PAGE_W + x0
            o[start:start + (x1 - x0)] = b"\x01" * (x1 - x0)
    return occ

def rect_is_free(o: bytearray, x: int, y: int, w: int, h: int, padding: int) -> bool:
    x0 = max(0, x - padding)
    y0 = max(0, y - padding)
    x1 = min(PAGE_W, x + w + padding)
    y1 = min(PAGE_H, y + h + padding)
    for yy in range(y0, y1):
        row = o[yy * PAGE_W + x0: yy * PAGE_W + x1]
        if any(row):
            return False
    return True

def mark_rect(o: bytearray, x: int, y: int, w: int, h: int, padding: int):
    x0 = max(0, x - padding)
    y0 = max(0, y - padding)
    x1 = min(PAGE_W, x + w + padding)
    y1 = min(PAGE_H, y + h + padding)
    for yy in range(y0, y1):
        start = yy * PAGE_W + x0
        o[start:start + (x1 - x0)] = b"\x01" * (x1 - x0)

def find_space(occ, w: int, h: int, padding: int):
    # Page 13 has by far the most free space in the stock font.
    page_order = [13] + list(range(12, -1, -1))
    for page in page_order:
        o = occ[page]
        # Scan from top-left. Existing glyph rectangles are never moved.
        for y in range(padding, PAGE_H - h - padding + 1):
            for x in range(padding, PAGE_W - w - padding + 1):
                if rect_is_free(o, x, y, w, h, padding):
                    mark_rect(o, x, y, w, h, padding)
                    return page, x, y
    return None

def cp932_pua_pool(existing_codes: set[int]):
    """Unused CP932 user-defined area: F040-F9FC, excluding 7F trails."""
    for lead in range(0xF0, 0xFA):
        for trail in range(0x40, 0xFD):
            if trail == 0x7F:
                continue
            code = (lead << 8) | trail
            if code in existing_codes:
                continue
            try:
                bytes([lead, trail]).decode("cp932")
            except Exception:
                continue
            yield code

def render_glyph(font_path: Path, char: str, font_size: int, baseline: int,
                 cell_height: int, advance: int):
    font = ImageFont.truetype(str(font_path), font_size)
    # Baseline-relative bbox. Pillow/FreeType returns e.g. y<0 for ascent.
    probe = Image.new("L", (128, 128), 0)
    draw = ImageDraw.Draw(probe)
    bbox = draw.textbbox((0, 0), char, font=font, anchor="ls")
    if bbox is None:
        raise ValueError(f"TTF has no drawable glyph for {repr(char)}.")
    l, t, r, b = bbox
    w0, h0 = max(1, r-l), max(1, b-t)

    img = Image.new("L", (w0, h0), 0)
    d = ImageDraw.Draw(img)
    # Move bbox top-left to (0,0); anchor point becomes (-l,-t).
    d.text((-l, -t), char, font=font, fill=255, anchor="ls")

    # Where baseline sits inside the cropped glyph.
    baseline_in_crop = -t

    # Fit into the game's half-width cell without changing advance.
    max_w = max(1, advance)
    max_h = max(1, cell_height)
    scale = min(1.0, max_w / img.width, max_h / img.height)
    if scale < 1.0:
        nw = max(1, round(img.width * scale))
        nh = max(1, round(img.height * scale))
        baseline_in_crop = round(baseline_in_crop * scale)
        img = img.resize((nw, nh), Image.Resampling.LANCZOS)

    # Trim zero-only border introduced by font bbox quirks.
    bb = img.getbbox()
    if bb:
        left_trim, top_trim, right_trim, bottom_trim = bb
        img = img.crop(bb)
        baseline_in_crop -= top_trim

    w, h = img.size
    top = baseline - baseline_in_crop

    # Keep the bitmap in the game's 22px character box.
    if top < 0:
        top = 0
    if top + h > cell_height:
        # Prefer retaining bottom/descender; shift up before resizing again.
        top = max(0, cell_height - h)
    if h > cell_height:
        nh = cell_height
        nw = max(1, round(w * nh / h))
        img = img.resize((nw, nh), Image.Resampling.LANCZOS)
        w, h = img.size
        top = 0
    if w > advance:
        nw = advance
        nh = max(1, round(h * nw / w))
        img = img.resize((nw, nh), Image.Resampling.LANCZOS)
        w, h = img.size
        top = min(max(0, top), cell_height - h)

    return img, top

def paint_glyph(linear: bytearray, alpha_img: Image.Image, x: int, y: int):
    pix = alpha_img.tobytes()
    w, h = alpha_img.size
    for yy in range(h):
        for xx in range(w):
            a = pix[yy * w + xx]
            dst = ((y + yy) * PAGE_W + (x + xx)) * 4
            # Stock atlas stores white RGB and the actual antialiased glyph in alpha.
            linear[dst + 0] = 255
            linear[dst + 1] = 255
            linear[dst + 2] = 255
            linear[dst + 3] = a

def normalized_unique_chars(text: str):
    seen = set()
    result = []
    for c in text:
        if c.isspace():
            continue
        if c not in seen:
            seen.add(c)
            result.append(c)
    return result

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("DFCI Font Tool - TTF → Font00.fnt / GXT")
        self.geometry("920x720")
        self.minsize(820, 650)

        self.src_var = tk.StringVar()
        self.ttf_var = tk.StringVar()
        self.out_var = tk.StringVar()
        self.mode_var = tk.StringVar(value="CP932 tunnel (recommended)")
        self.size_var = tk.IntVar(value=22)
        self.baseline_var = tk.IntVar(value=19)
        self.cellh_var = tk.IntVar(value=22)
        self.advance_var = tk.IntVar(value=11)
        self.padding_var = tk.IntVar(value=1)

        self._build_ui()

    def _build_ui(self):
        root = ttk.Frame(self, padding=12)
        root.pack(fill="both", expand=True)

        files = ttk.LabelFrame(root, text="Input / Output", padding=10)
        files.pack(fill="x")

        self._path_row(files, 0, "Font folder:", self.src_var, self.choose_src)
        self._path_row(files, 1, "TTF / OTF:", self.ttf_var, self.choose_ttf)
        self._path_row(files, 2, "Output folder:", self.out_var, self.choose_out)

        opts = ttk.LabelFrame(root, text="Font build settings", padding=10)
        opts.pack(fill="x", pady=(10,0))

        ttk.Label(opts, text="Encoding:").grid(row=0, column=0, sticky="w", padx=4, pady=4)
        ttk.Combobox(
            opts, textvariable=self.mode_var, state="readonly", width=31,
            values=["CP932 tunnel (recommended)", "Unicode direct (experimental)"]
        ).grid(row=0, column=1, sticky="w", padx=4)

        labels = [
            ("TTF size", self.size_var),
            ("Baseline", self.baseline_var),
            ("Cell height", self.cellh_var),
            ("Advance", self.advance_var),
            ("Atlas padding", self.padding_var),
        ]
        for i, (name, var) in enumerate(labels, start=2):
            ttk.Label(opts, text=name + ":").grid(row=0, column=i, sticky="e", padx=(10,2))
            ttk.Spinbox(opts, from_=0, to=64, textvariable=var, width=5).grid(row=0, column=i+1, sticky="w")

        chars = ttk.LabelFrame(root, text="Characters to ensure exist", padding=10)
        chars.pack(fill="both", expand=False, pady=(10,0))
        self.char_text = tk.Text(chars, height=6, wrap="char")
        self.char_text.pack(fill="both", expand=True)
        self.char_text.insert("1.0", VIETNAMESE_CHARSET)

        buttons = ttk.Frame(root)
        buttons.pack(fill="x", pady=10)
        ttk.Button(buttons, text="Analyze", command=self.analyze).pack(side="left")
        ttk.Button(buttons, text="Build font", command=self.build).pack(side="left", padx=8)
        ttk.Button(buttons, text="Restore Vietnamese set", command=self.restore_chars).pack(side="left")

        logframe = ttk.LabelFrame(root, text="Log", padding=8)
        logframe.pack(fill="both", expand=True)
        self.logbox = tk.Text(logframe, height=18, wrap="word", state="disabled")
        self.logbox.pack(fill="both", expand=True)

    def _path_row(self, parent, row, label, var, command):
        ttk.Label(parent, text=label, width=14).grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(parent, textvariable=var).grid(row=row, column=1, sticky="ew", padx=6)
        ttk.Button(parent, text="Browse…", command=command).grid(row=row, column=2)
        parent.grid_columnconfigure(1, weight=1)

    def choose_src(self):
        p = filedialog.askdirectory(title="Folder containing Font00.fnt + Font_0000..0013.gxt.gz")
        if p:
            self.src_var.set(p)
            if not self.out_var.get():
                self.out_var.set(str(Path(p).parent / (Path(p).name + "_VI")))

    def choose_ttf(self):
        p = filedialog.askopenfilename(
            title="Choose TTF/OTF",
            filetypes=[("TrueType / OpenType", "*.ttf *.otf"), ("All files", "*.*")]
        )
        if p:
            self.ttf_var.set(p)

    def choose_out(self):
        p = filedialog.askdirectory(title="Choose output folder")
        if p:
            self.out_var.set(p)

    def restore_chars(self):
        self.char_text.delete("1.0", "end")
        self.char_text.insert("1.0", VIETNAMESE_CHARSET)

    def log(self, s=""):
        self.logbox.configure(state="normal")
        self.logbox.insert("end", s + "\n")
        self.logbox.see("end")
        self.logbox.configure(state="disabled")
        self.update_idletasks()

    def validate_inputs(self, need_ttf=True):
        src = Path(self.src_var.get())
        if not src.is_dir():
            raise ValueError("Choose the source font folder.")
        if not (src / "Font00.fnt").is_file():
            raise ValueError("Font00.fnt not found.")
        for p in range(NORMAL_PAGE_COUNT):
            fn = src / f"Font_{p:04d}.gxt.gz"
            if not fn.is_file():
                raise ValueError(f"{fn.name} not found.")
        ttf = Path(self.ttf_var.get())
        if need_ttf and not ttf.is_file():
            raise ValueError("Choose a TTF/OTF font.")
        return src, ttf

    def analyze(self):
        try:
            self.logbox.configure(state="normal")
            self.logbox.delete("1.0", "end")
            self.logbox.configure(state="disabled")
            src, _ = self.validate_inputs(need_ttf=False)
            header, glyphs, tail = load_fnt(src / "Font00.fnt")
            wanted = normalized_unique_chars(self.char_text.get("1.0", "end"))
            decoded = {}
            for g in glyphs:
                c = decode_existing_code(g.code)
                if c:
                    decoded.setdefault(c, g.code)
            missing = [c for c in wanted if c not in decoded]
            self.log(f"Glyph records: {len(glyphs)}")
            self.log(f"Header atlas count: {struct.unpack_from('<H', header, 0x38)[0]}")
            self.log(f"Requested characters: {len(wanted)}")
            self.log(f"Already present through CP932: {len(wanted)-len(missing)}")
            self.log(f"Missing: {len(missing)}")
            self.log("Missing characters:")
            self.log("".join(missing) if missing else "(none)")
            self.log("")
            self.log("Pages 0000..0013 will be reused; page 0014 is never modified.")
        except Exception as e:
            messagebox.showerror("Analyze failed", str(e))
            self.log(traceback.format_exc())

    def build(self):
        try:
            src, ttf = self.validate_inputs(need_ttf=True)
            out = Path(self.out_var.get())
            if not str(out):
                raise ValueError("Choose an output folder.")
            if src.resolve() == out.resolve():
                raise ValueError("Output folder must differ from source. The tool writes modified pages there.")

            font_size = int(self.size_var.get())
            baseline = int(self.baseline_var.get())
            cell_h = int(self.cellh_var.get())
            advance = int(self.advance_var.get())
            padding = int(self.padding_var.get())
            if font_size <= 0 or cell_h <= 0 or advance <= 0:
                raise ValueError("Font size, cell height and advance must be positive.")
            if not (0 <= baseline <= cell_h):
                raise ValueError("Baseline must be within cell height.")
            if padding < 0 or padding > 4:
                raise ValueError("Atlas padding should be 0..4.")

            self.logbox.configure(state="normal")
            self.logbox.delete("1.0", "end")
            self.logbox.configure(state="disabled")

            self.log("Loading Font00.fnt…")
            header, glyphs, tail = load_fnt(src / "Font00.fnt")
            wanted = normalized_unique_chars(self.char_text.get("1.0", "end"))

            existing_char_codes = {}
            existing_codes = {g.code for g in glyphs}
            for g in glyphs:
                c = decode_existing_code(g.code)
                if c:
                    existing_char_codes.setdefault(c, g.code)

            missing = [c for c in wanted if c not in existing_char_codes]
            self.log(f"{len(wanted)} requested; {len(missing)} are missing.")
            if not missing:
                messagebox.showinfo("Nothing to add", "All requested characters already exist.")
                return

            out.mkdir(parents=True, exist_ok=True)
            # Preserve every source file, including Font_0014.gxt.gz.
            for item in src.iterdir():
                if item.is_file():
                    shutil.copy2(item, out / item.name)

            self.log("Loading atlas pages 0000..0013…")
            pages = {}
            for p in range(NORMAL_PAGE_COUNT):
                h, linear = read_gxt_rgba(src / f"Font_{p:04d}.gxt.gz")
                pages[p] = [h, linear]

            occ = build_occupancy(glyphs, padding)
            mapping = {}
            mode_tunnel = self.mode_var.get().startswith("CP932")
            tunnel_codes = cp932_pua_pool(existing_codes)

            added = []
            dirty_pages = set()

            for idx, char in enumerate(missing, 1):
                if mode_tunnel:
                    try:
                        code = next(tunnel_codes)
                    except StopIteration:
                        raise RuntimeError("Ran out of unused CP932 tunneling codes.")
                else:
                    code = ord(char)
                    if code in existing_codes:
                        # A direct code already exists, even if it did not decode as CP932.
                        self.log(f"Skip {char}: code U+{ord(char):04X} already exists as 0x{code:X}.")
                        continue

                alpha, top = render_glyph(ttf, char, font_size, baseline, cell_h, advance)
                w, h = alpha.size
                pos = find_space(occ, w, h, padding)
                if pos is None:
                    raise RuntimeError(
                        f"No free rectangle remains in pages 0000..0013 for {repr(char)} "
                        f"({w}x{h}). No files were replaced in the source folder."
                    )
                page, ax, ay = pos
                paint_glyph(pages[page][1], alpha, ax, ay)
                dirty_pages.add(page)

                left = max(0, (advance - w) // 2)
                center_x = left + (w // 2)
                g = Glyph(
                    code=code,
                    page=page,
                    center_x=center_x,
                    neg_half_width=-(w // 2),
                    neg_top=-top,
                    advance=advance,
                    width=w,
                    height=h,
                    atlas_x=ax,
                    atlas_y=ay,
                )
                glyphs.append(g)
                existing_codes.add(code)

                ent = {
                    "char": char,
                    "unicode": f"U+{ord(char):04X}",
                    "fnt_code": f"0x{code:04X}" if code <= 0xFFFF else f"0x{code:X}",
                    "page": page,
                    "atlas": [ax, ay, w, h],
                    "advance": advance,
                    "top": top,
                }
                if mode_tunnel:
                    ent["cp932_bytes_hex"] = f"{(code>>8)&0xFF:02X} {code&0xFF:02X}"
                    try:
                        ent["cp932_placeholder_unicode"] = (
                            f"U+{ord(bytes([(code>>8)&0xFF, code&0xFF]).decode('cp932')):04X}"
                        )
                    except Exception:
                        pass
                mapping[char] = ent
                added.append(ent)
                self.log(
                    f"[{idx:03d}/{len(missing):03d}] {char} -> "
                    f"code {ent['fnt_code']}, page {page:02d}, "
                    f"({ax},{ay}) {w}x{h}"
                )

            self.log("Writing modified atlas pages…")
            for p in sorted(dirty_pages):
                write_gxt_rgba(
                    out / f"Font_{p:04d}.gxt.gz",
                    pages[p][0], pages[p][1]
                )
                self.log(f"  wrote Font_{p:04d}.gxt.gz")

            save_fnt(out / "Font00.fnt", header, glyphs, tail)

            manifest = {
                "tool": "DFCI Font Tool",
                "mode": "cp932_tunnel" if mode_tunnel else "unicode_direct",
                "source_glyph_count": len(glyphs) - len(added),
                "new_glyph_count": len(added),
                "final_glyph_count": len(glyphs),
                "font_file": str(ttf.name),
                "font_size": font_size,
                "baseline": baseline,
                "cell_height": cell_h,
                "advance": advance,
                "atlas_padding": padding,
                "mapping": mapping,
            }
            (out / "vi_mapping.json").write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
            )

            with open(out / "vi_mapping.tsv", "w", encoding="utf-8", newline="\n") as f:
                if mode_tunnel:
                    f.write("char\tunicode\tfnt_code\tcp932_bytes_hex\tpage\tx\ty\tw\th\n")
                    for e in added:
                        f.write(
                            f"{e['char']}\t{e['unicode']}\t{e['fnt_code']}\t"
                            f"{e.get('cp932_bytes_hex','')}\t{e['page']}\t"
                            f"{e['atlas'][0]}\t{e['atlas'][1]}\t"
                            f"{e['atlas'][2]}\t{e['atlas'][3]}\n"
                        )
                else:
                    f.write("char\tunicode\tfnt_code\tpage\tx\ty\tw\th\n")
                    for e in added:
                        f.write(
                            f"{e['char']}\t{e['unicode']}\t{e['fnt_code']}\t"
                            f"{e['page']}\t{e['atlas'][0]}\t{e['atlas'][1]}\t"
                            f"{e['atlas'][2]}\t{e['atlas'][3]}\n"
                        )

            self.log("")
            self.log(f"Done. Added {len(added)} glyphs.")
            self.log(f"Dirty pages: {', '.join(f'{p:04d}' for p in sorted(dirty_pages))}")
            self.log(f"Final FNT glyph count: {len(glyphs)}")
            self.log(f"Output: {out}")
            self.log("Font_0014.gxt.gz was copied unchanged.")
            messagebox.showinfo(
                "Build complete",
                f"Added {len(added)} missing glyphs.\n"
                f"Modified existing pages only: {', '.join(str(p) for p in sorted(dirty_pages))}\n\n"
                f"Output:\n{out}"
            )

        except Exception as e:
            messagebox.showerror("Build failed", str(e))
            self.log("")
            self.log("ERROR:")
            self.log(traceback.format_exc())

if __name__ == "__main__":
    App().mainloop()
