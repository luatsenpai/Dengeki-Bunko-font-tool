# DFCI Font Tool

Tool GUI for the Vita version of **Dengeki Bunko: Fighting Climax Ignition**.

## What it does

- Reads `Font00.fnt`.
- Reads `Font_0000.gxt.gz` … `Font_0013.gxt.gz`.
- Loads a TTF/OTF font.
- Checks which requested characters already exist.
- Creates **only missing glyphs**.
- Finds empty rectangles in the existing 512×512 atlas pages.
- Never moves/re-packs old glyphs, so all old UV coordinates remain unchanged.
- Writes only the atlas pages that actually received new glyphs.
- Leaves `Font_0014.gxt.gz` unchanged.
- Updates the `Font00.fnt` glyph count and appends new records.
- Exports `vi_mapping.json` and `vi_mapping.tsv`.

## Recommended mode: CP932 tunnel

The stock FNT identifies Japanese characters with Shift-JIS / CP932 byte codes, not normal Unicode
codepoints. Vietnamese precomposed letters are not representable in CP932.

The default mode therefore assigns missing Vietnamese glyphs to unused CP932 **user-defined area**
codes (`F040..F9FC`). The tool exports the exact mapping, for example:

    ă -> F0 40
    â -> F0 41

The translated text must later be encoded using the same mapping. `vi_mapping.json` / `.tsv`
are intended to be consumed by the text insertion tool.

`Unicode direct` is included only for testing if the game's text decoder has already been patched
to feed Unicode values directly to the font lookup.

## Defaults

- TTF size: 22 px
- Font cell height: 22 px
- Baseline: 19 px
- Half-width advance: 11 px
- Atlas padding: 1 px

These match the observed stock `Font00.fnt` layout closely.

## Requirements

- Windows / Linux
- Python 3.10+
- Pillow

Install:

    py -m pip install Pillow

Then run:

    py dfci_font_tool.py

On Linux use `python3` instead of `py`.

## Safety

Do not choose the original font folder as Output. The tool deliberately requires a separate output
folder. After testing, copy the generated files into the game's extracted font directory yourself.

## Files currently supported

- `Font00.fnt`
- `Font_0000.gxt.gz` … `Font_0013.gxt.gz`

`Font_0014.gxt.gz` is BC3/DXT5 and is not referenced by the parsed `Font00.fnt` records, so this
tool intentionally does not modify it.
